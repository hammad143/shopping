class OnBoardModel {
  final String title, desc, img_src;

  OnBoardModel({this.title, this.desc, this.img_src});
}

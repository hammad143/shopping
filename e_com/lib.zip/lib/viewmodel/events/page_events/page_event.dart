import 'package:equatable/equatable.dart';

abstract class PageEvent extends Equatable {
  @override
  List<Object> get props => [];
}

import 'package:e_com/util/constants/main_const.dart';
import 'package:flutter/material.dart';

class Style {
  static final TextStyle black54 = TextStyle(
    fontSize: kNormalFontSize,
    color: Colors.black54,
  );
}

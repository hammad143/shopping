import 'package:flutter/material.dart';

const Color kPrimaryColor = const Color(0xfff56262);
const Color kSecondaryColor = const Color(0xffbababa);

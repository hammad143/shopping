import 'package:device_preview/device_preview.dart';
import 'package:flutter/cupertino.dart';

abstract class DeviceSizeInfo {
  double deviceWidth, deviceHeight;
  Orientation orientation;
}

class Routes {
  static final String onboard = "/onboard";
  static final String login = "/login";
  static final String logout = "/logout";
  static final String signup = "/signup";
}
